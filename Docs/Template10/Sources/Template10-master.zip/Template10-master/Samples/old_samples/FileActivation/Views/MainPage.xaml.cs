using Windows.UI.Xaml.Controls;

namespace Template10.Samples.FileActivationSample.Views
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
