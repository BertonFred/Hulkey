﻿using Windows.UI.Xaml.Controls;

namespace Template10.Samples.SearchSample.Views
{
    public sealed partial class GalleryPage : Page
    {
        public GalleryPage()
        {
            this.InitializeComponent();
        }
    }
}
