﻿#MVVM Light

Template 10 is compatible with all MVVM frameworks, including MVVM Light. MVVM Light is one of the most popular third-party model-view-viewmodel frameworks. This demonstrates a simple implementation. 

##Mvvm/ViewModelBase.cs

##ViewModels/ViewModelLocator.cs

##App.xaml.cs

##Views/MainPage.xaml