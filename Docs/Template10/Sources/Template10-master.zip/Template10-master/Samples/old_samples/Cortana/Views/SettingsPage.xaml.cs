﻿using Windows.UI.Xaml.Controls;

namespace Template10.Samples.CortanaSample.Views
{
    public sealed partial class SettingsPage : Page
    {
        public SettingsPage()
        {
            this.InitializeComponent();
        }
    }
}
