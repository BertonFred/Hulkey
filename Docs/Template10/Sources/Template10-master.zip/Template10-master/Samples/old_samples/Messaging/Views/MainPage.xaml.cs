using Windows.UI.Xaml.Controls;

namespace Template10.Samples.MessagingSample.Views
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
