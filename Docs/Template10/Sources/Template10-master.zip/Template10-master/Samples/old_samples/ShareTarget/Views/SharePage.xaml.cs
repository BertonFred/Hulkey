using Windows.UI.Xaml.Controls;

namespace Template10.Samples.ShareTargetSample.Views
{
    public sealed partial class SharePage : Page
    {
        public SharePage()
        {
            InitializeComponent();
        }
    }
}
