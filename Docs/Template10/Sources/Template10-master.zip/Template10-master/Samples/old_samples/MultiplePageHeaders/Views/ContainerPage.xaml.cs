﻿using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace MultiplePageHeaders.Views
{
    public sealed partial class ContainerPage : Page
    {
        public ContainerPage()
        {
            InitializeComponent();
        }
    }
}
