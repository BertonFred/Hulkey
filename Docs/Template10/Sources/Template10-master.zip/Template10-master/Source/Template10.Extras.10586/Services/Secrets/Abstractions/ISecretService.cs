﻿namespace Template10.Services.Secrets
{
    public interface ISecretService
    {
        string ConnectionString { get; set; }
    }
}