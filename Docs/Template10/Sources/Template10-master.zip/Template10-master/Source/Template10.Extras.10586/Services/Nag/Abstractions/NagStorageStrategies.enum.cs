﻿namespace Template10.Services.Nag
{
    public enum NagStorageStrategies { Local, Roaming, Temporary }
}
