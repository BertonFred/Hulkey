﻿namespace Template10.Services.Network
{
    public enum ConnectionTypes
    {
        None,
        LocalNetwork,
        Internet
    }
}
