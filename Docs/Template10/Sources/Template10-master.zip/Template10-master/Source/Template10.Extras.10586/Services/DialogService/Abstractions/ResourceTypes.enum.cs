﻿namespace Template10.Services.Dialog
{
    public enum ResourceTypes { Ok, Yes, No, Cancel }
}
