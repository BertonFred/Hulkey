﻿namespace Template10.Services.Dialog
{
    public enum MessageBoxResult
    {
        Cancel,
        No,
        Ok,
        Yes,
    }
}
