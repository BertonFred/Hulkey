﻿namespace Template10.Services.Dialog
{
    public enum MessageBoxType
    {
        Ok,
        OkCancel,
        YesNo,
        YesNoCancel
    }
}
