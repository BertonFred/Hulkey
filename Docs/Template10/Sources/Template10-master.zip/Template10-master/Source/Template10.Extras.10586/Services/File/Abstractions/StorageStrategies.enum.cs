﻿namespace Template10.Services.File
{
    public enum StorageStrategies { Local, Roaming, Temporary }
}
