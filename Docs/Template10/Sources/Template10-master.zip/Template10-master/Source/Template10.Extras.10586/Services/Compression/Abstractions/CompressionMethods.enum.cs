﻿namespace Template10.Services.Compression
{
    public enum CompressionMethods { gzip }
}
