﻿using Template10.Services.Dialog;

namespace Template10.Services.Nag
{
    public static class Settings
    {
        public static IDialogResourceResolver CustomResolver { get; set; } = null;
    }
}
