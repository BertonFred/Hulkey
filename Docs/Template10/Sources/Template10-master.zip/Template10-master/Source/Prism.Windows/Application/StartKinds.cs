﻿namespace Prism
{
    public enum StartKinds { Prelaunch, Launch, Activate, Background,
        Resume
    }
}
