﻿namespace Prism.Navigation
{

    public enum NavigationMode
    {
        Back,
        New,
        Forward,
        Refresh,
    }
}
