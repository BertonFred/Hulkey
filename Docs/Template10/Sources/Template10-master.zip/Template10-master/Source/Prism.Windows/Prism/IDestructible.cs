﻿namespace Prism.Navigation
{
    public interface IDestructible
    {
        void Destroy();
    }
}
