## Template 10: Getting Started

**Ready to use Template 10?**

Just open Visual Studio 2017 & search "Template 10" in the Extension Manager. After installing, go File>New>Project and choose a Template 10 project template.

**Learn more:**

1. Docs: http://aka.ms/Template10
2. Training: https://mva.microsoft.com/en-us/training-courses/getting-started-with-template-10-16336

## About Template 10.1

The current version of Template 10 is good to go. Want to learn more about it? Watch this full-day course. 
Are you looking for the code currently in Nuget?

> https://github.com/Windows-XAML/Template10/tree/version_1.1.12

## About Template 10.2

We are building the next version of Template 10. We might not get finished before the Fall Creators Update, so we don't recommend waiting for it. Aside: the work on 10.2 is what you find in the `master` branch.